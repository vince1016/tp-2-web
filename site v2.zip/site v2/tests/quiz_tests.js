QUnit.test( "choisirQuestions", function( assert ) {
    //arrenge

    assert.();
  });