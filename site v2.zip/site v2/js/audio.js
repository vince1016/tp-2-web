// Source : https://www.w3schools.com/jsref/met_audio_play.asp

function jouerSon(elementId)
{
	var audio = document.getElementById(elementId); 
	audio.play(); 
}